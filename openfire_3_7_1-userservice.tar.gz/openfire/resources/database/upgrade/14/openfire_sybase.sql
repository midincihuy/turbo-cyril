/* jiveRoster: Can not add indexes on TEXT fields in Sybase, just updating version. */

UPDATE jiveVersion set version=14 where name = 'openfire';
